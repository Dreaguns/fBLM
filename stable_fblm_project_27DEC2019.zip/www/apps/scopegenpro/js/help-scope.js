var helpListScope = 
{
  idle: [
    {
      Text: "What is Oscilloscope?",
      URL: "https://en.wikipedia.org/wiki/Oscilloscope",
      Img: "pool"
    },
    {
      Text: "Oscilloscope characteristics",
      URL: "http://wiki.redpitaya.com/index.php?title=Oscilloscope_and_Signal_Generator",
      Img: "star"
    },
    {
      Text: "Red Pitaya's Forum",
      URL: "http://forum.redpitaya.com/",
      Img: "star"
    }
  ],
  loaded: [
    {
      Text: "Description3",
      URL: "http://redpitaya.com",
      Img: "star"
    },
    {
      Text: "Description4",
      URL: "http://redpitaya.com",
      Img: "pool"
    }
  ]
};