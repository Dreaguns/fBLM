hamrf -s
gpiorelay -s

/opt/redpitaya/www/apps/stemlab_sdr_transceiver_hpsdr/sdr-transceiver-hpsdr &
