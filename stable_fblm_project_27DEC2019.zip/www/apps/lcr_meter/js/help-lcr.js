var helpListLCR = 
{
  idle: [
    {
      Text: "LCR Meter extension board",
      URL: "http://store.redpitaya.com/red-pitaya-shield-23.html",
      Img: "pool"
    },
    {
      Text: "LCR Meter and Impedance Analyzer guide",
      URL: "http://wiki.redpitaya.com/index.php?title=Impedance_analyzer",
      Img: "star"
    },
    {
      Text: "Red Pitaya's Forum",
      URL: "http://forum.redpitaya.com/",
      Img: "star"
    }
  ],
  loaded: [
    {
      Text: "Description3",
      URL: "http://redpitaya.com",
      Img: "star"
    },
    {
      Text: "Description4",
      URL: "http://redpitaya.com",
      Img: "pool"
    }
  ]
};