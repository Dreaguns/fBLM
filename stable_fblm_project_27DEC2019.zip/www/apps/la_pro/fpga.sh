#!/bin/sh

# DO NOT EDIT
/opt/redpitaya/sbin/mkoverlay.sh logic
