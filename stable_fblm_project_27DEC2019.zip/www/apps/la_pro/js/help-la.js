var helpListLA = 
{
  idle: [
    {
      Text: "Logic Analyser extension board",
      URL: "http://store.redpitaya.com/logic-analyzer.html",
      Img: "pool"
    },
    {
      Text: "Red Pitaya's Forum",
      URL: "http://forum.redpitaya.com/",
      Img: "star"
    }
  ]
};