/opt/redpitaya/www/apps/stemlab_vna/vna &
