killall vna
