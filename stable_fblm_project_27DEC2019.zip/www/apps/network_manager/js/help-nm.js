var helpListNM = 
{
  idle: [
    {
      Text: "Red Pitaya's Forum",
      URL: "http://forum.redpitaya.com/",
      Img: "star"
    }
  ]
};