var helpListSCPI = 
{
  idle: [
    {
      Text: "How to control your Red Pitaya remotely?",
      URL: "http://redpitaya.com/control/",
      Img: "pool"
    },
    {
      Text: "Red Pitaya's Forum",
      URL: "http://forum.redpitaya.com/",
      Img: "star"
    }
  ],
  loaded: [
    {
      Text: "Description3",
      URL: "http://redpitaya.com",
      Img: "star"
    },
    {
      Text: "Description4",
      URL: "http://redpitaya.com",
      Img: "pool"
    }
  ]
};