var helpListSpectrum = 
{
  idle: [
    {
      Text: "What is the Spectrum Alanyser?",
      URL: "https://en.wikipedia.org/wiki/Spectrum_analyzer",
      Img: "pool"
    },
    {
      Text: "Spectrum Alanyser characteristics",
      URL: "http://wiki.redpitaya.com/index.php?title=Spectrum_analyzer",
      Img: "star"
    },
    {
      Text: "Red Pitaya's Forum",
      URL: "http://forum.redpitaya.com/",
      Img: "star"
    }
  ],
  loaded: [
    {
      Text: "Description3",
      URL: "http://redpitaya.com",
      Img: "star"
    },
    {
      Text: "Description4",
      URL: "http://redpitaya.com",
      Img: "pool"
    }
  ]
};