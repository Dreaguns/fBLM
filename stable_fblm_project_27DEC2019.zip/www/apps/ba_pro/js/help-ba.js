var helpListBA = 
{
  idle: [
    {
      Text: "What is Bode Plot?",
      URL: "https://en.wikipedia.org/wiki/Bode_plot",
      Img: "pool"
    },
    {
      Text: "Bode Analyser characteristics",
      URL: "http://wiki.redpitaya.com/index.php?title=Bode_analyzer",
      Img: "pool"
    },
    {
      Text: "Red Pitaya's Forum",
      URL: "http://forum.redpitaya.com/",
      Img: "star"
    }
  ],
  loaded: [
    {
      Text: "Description3",
      URL: "http://redpitaya.com",
      Img: "star"
    },
    {
      Text: "Description4",
      URL: "http://redpitaya.com",
      Img: "pool"
    }
  ]
};