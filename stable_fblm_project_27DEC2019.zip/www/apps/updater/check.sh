#!/bin/bash
wc -c /tmp/build/build.zip
