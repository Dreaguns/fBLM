#!/bin/bash
cd /tmp/build && unzip build.zip &> /dev/null && rm build.zip &> /dev/null

echo "OK"
